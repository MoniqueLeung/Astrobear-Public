﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;

public class PlayerSample1 : NetworkBehaviour
{

  //public float speed;

    // Start is called before the first frame update
//    void Start()
//    {

//    }

//void MomoMovement(){


//  if(isLocalPlayer){
//    float MoveHorizontal = Input.GetAxis("Horizontal");
//    float MoveVertical = Input.GetAxis("Vertical");
  //  vector3 movement = new Vector3(MoveHorizontal * 0.1f, moveVertical * (0.1f,0);

//    transform.position = transform.position + movement * speed;


//  }
//}
    // Update is called once per frame
//    void Update()
//    {
//      MomoMovement();
//    }
}
