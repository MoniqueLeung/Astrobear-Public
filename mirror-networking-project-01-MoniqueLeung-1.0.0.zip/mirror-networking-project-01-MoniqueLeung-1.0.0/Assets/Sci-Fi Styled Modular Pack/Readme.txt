+-------------------------------------------+
|  COLOR PALETTE                            |
+-------------------------------------------+

All models have one base material. If you want to change a color palette for all of it, just change Albedo texture in "base material".

If you want change color pallete, just drag and drop selected material to prefab. But remember, since some of the models have LOD Group attached, you have to change material for all models inside that prefab. For example:
   Prefabs/Floors/floor_2.prefab have two LOD models inside it: floor_2_LOD0 and floor_FOD_1. You have to change material for both.
   
+-------------------------------------------+
|  MODULAR LEVEL DESIGN                     |
+-------------------------------------------+

Most of the prefabs was designed to aligned to each other. Just remember to use Pivot point insted of Center point.

+-------------------------------------------+
|  DEMO SCENES                              |
+-------------------------------------------+

Package have two example scene, where you can see what you can do with this pack. If you going to check them, these Standard Assets have to be imported to your project:
Characters, Effects

+-------------------------------------------+
|  SUPPORT                                  |
+-------------------------------------------+

In case of any questions, please contact with me by email:

	karbo243@gmail.com