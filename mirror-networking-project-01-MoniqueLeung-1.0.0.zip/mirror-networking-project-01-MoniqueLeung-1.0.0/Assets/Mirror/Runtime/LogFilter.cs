namespace Mirror
{
    public static class LogFilter
    {
        public static bool Debug = false;
    }
}
