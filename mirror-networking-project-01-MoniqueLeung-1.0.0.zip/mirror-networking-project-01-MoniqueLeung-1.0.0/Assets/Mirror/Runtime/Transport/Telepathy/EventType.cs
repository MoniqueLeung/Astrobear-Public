﻿namespace Telepathy
{
    public enum EventType
    {
        Connected,
        Data,
        Disconnected
    }
}
