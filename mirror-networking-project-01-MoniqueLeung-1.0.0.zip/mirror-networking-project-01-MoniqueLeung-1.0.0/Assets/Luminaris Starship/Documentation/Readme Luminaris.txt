Luminaris Starship low-poly 3d model  (4078 polys, 4373 Verts) ready for Virtual Reality (VR), Augmented Reality (AR), games and other real-time apps.

This drone is low-poly model of a deep space exploration craft of my own design. 
You can use it for your video game (all from mobile to next gen consoles) ,concept overpaint asset,matte painting element, animation,personal practice(reverse engineering) ,movie project or just having fun in any way yo can think of.


There are four classic 4K texture files 4096 x 4096 in .tga format  (diffuse/emissive/specular PBR /normal)
For creation video follow this link:  https://www.youtube.com/watch?v=8MXeav4rRMg

 
If you need any other information ,feel free to contact me.  puskaric82@gmail.com

I hope you will enjoy in your model as I enjoyed creating it. 
Thank you!

Igor